Kyromentium.exe
There is 20 GDI Effects 
Run It On Windows 7 - 11
-------------------------------------
Malware By RikGDI

https//www.youtube.com/@win32.rikgdi
https//www.github.com/rikgdi
--------------------------------------